package StepDefination;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.utils.HelperClass;

import PageObjects.regression;
import PageObjects.smoke;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class stepdef2 {
	
	//public static WebDriver driver = HelperClass.getDriver();
	public static WebDriver driver;
	smoke f1;
	regression f2 ;
	static Properties Pr;
	
	@Given("Homepage of Zigwheels")
	 public  void homepage_of_zig_wheels() {

		driver = HelperClass.getDriver();
		f1 = new smoke(driver);
		f2 = new regression(driver);
	}
	
	
	@When("user Hover on Used Cars")
	public void user_hover_on_used_cars() {
	    f2.hoverUsedcar();
	}

	@Then("Dropdown is displayed")
	public void dropdown_is_displayed() {
	  f2.cheakdrpDown();
	}

	@When("User Cliks on the search Bar")
	public void user_cliks_on_the_search_bar() {
	   f2.clickSearch();
	}

	@Then("Search Options is displayed")
	public void search_options_is_displayed() {
	    f2.searchOptions();
	}
	@When("The user clicks on Login button")
	public void the_user_clicks_on_login_button() {
	   
		f2.clicklogin();
	}

	@Then("The user select google as login")
	public void the_user_select_google_as_login() {
		
		f2.selectgoogle();
		
	}

	@When("The user nevigates to login window")
	public void the_user_nevigates_to_login_window() {
		String originalWindow = driver.getWindowHandle();

		for (String windowHandle : driver.getWindowHandles()) { // to handle windows
			if (!originalWindow.contentEquals(windowHandle)) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	

	}

	@Then("User clicks the Next button")
	public void user_clicks_the_next_button() {
		f2.clickNext();
	}

	
	@When("User enters {string} email")
	public void user_enters_email(String string) {
		
		WebElement mail = f2.enterMail();
		mail.sendKeys(string);
	}

	@When("User enter the invalid {string}")
	public void user_enter_the_invalid(String string){
			
		f2.enterPass().sendKeys(string);
	}

	@Then("display the Password error message")
	public void display_the_password_error_message() {
	  
			f2.printError();
	}


	
	@Then("select Facebook as login option")
	public void select_facebook_as_login_option() {
		
		f2.selectfb();
		
	}

	@When("user Enters Invalid mail\\/ph {string}")
	public void user_enters_invalid_mail_ph(String fbcread) {
		
		f2.enterCred().sendKeys(fbcread); 
	}

	@When("user Enters Invalid Password {string}")
	public void user_enters_invalid_password(String string) {
	    
		f2.enterfbPass().sendKeys(string);
	}

	@Then("clicks Login button")
	public void clicks_login_button() {
	  
		f2.fbLogIn();
	}

	@Then("displays the facebook message")
	public void displays_the_facebook_message() {
	 
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 f2.Fberror();
	}
	

	@When("User hover on More in Header")
	public void user_hover_on_more_in_header() {
	    
		f2.hoverMore();
	}

	@When("Select Sell Car to Cardekho Gaadi Store")
	public void select_sell_car_to_cardekho_gaadi_store() {
	 
		f2.clickSellCar();
	}

	@Then("User is nevigated to the Car dekho home page")
	public void user_is_nevigated_to_the_car_dekho_home_page() throws IOException {
		
		Pr = HelperClass.getProperties();
		String expectedTitle = Pr.getProperty("CarDekh_Title");
		String actualTitle = driver.getTitle();

		Assert.assertEquals(actualTitle, expectedTitle);
		
	}
	
	@When("the User clicks on New Bikes")
	public void the_user_clicks_on_new_bikes() {
	    f2.clickNewBikes();
	}

	@When("the user clicks displacement filter")
	public void the_user_clicks_displacement_filter() {
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    f2.selectFilter();
	}

	@Then("the user selects bike a displacement range {string}")
	public void the_user_selects_bike_a_displacement_range(String range) {
	   
		for(WebElement ele :f2.displacementRanges()) 
		{
			if(ele.getText().equalsIgnoreCase(range))
				ele.click();
		}
	
		
	}

	@Then("Displays Bike name and Displacement")
	public void displays_bike_name_and_displacement() {
	    
		   f2.displaysResults();
		
	}

	
	@When("The User clicks on New Cars")
	public void the_user_clicks_on_new_cars() {
	   
			f2.clickNewCars();
	}

	@When("The User select Fuel Type filter")
	public void the_user_select_fuel_type_filter() {
		
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		f2.selectCarFilterType();
	}

	@Then("The User selcet Fuel Type {string}")
	public void the_user_selcet_fuel_type(String fuel) {
	  try { 
		for(WebElement ele :f2.fuelTypes()) 
		{
			if(ele.getText().equalsIgnoreCase(fuel))
				ele.click();
		}
	  }
	  catch(StaleElementReferenceException e) {
		  
	  }
	}

	@Then("Validate the Displayed result with {string}")
	public void validate_the_displayed_result_with(String fuel) {
		
		
		List<WebElement>re = f2.filteredResult();
		for(int i =0; i<re.size();i++)
		{
			String Actual = re.get(i).getText();
			String Expected= fuel;
			
			 Assert.assertTrue(Actual.contains(Expected));
			
		}
		
	}

	
	
}
