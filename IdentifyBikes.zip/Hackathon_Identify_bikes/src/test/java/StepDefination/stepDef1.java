package StepDefination;

import java.io.IOException;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.utils.HelperClass;

import PageObjects.regression;
import PageObjects.smoke;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDef1 {

	public static WebDriver driver;
	smoke f1;
	regression f2;
	static Properties Pr;

	@Given("Homepage of ZigWheels")
	 public  void homepage_of_zig_wheels() {

		driver = HelperClass.getDriver();
		f1 = new smoke(driver);
		//f2 = new regression(driver);
	}

	@Then("ZigWheels logo should be displayed")
	public void zig_wheels_logo_should_be_displayed() {

		f1.cheakLogo();

	}

	@Then("Searchbox should be displayed")
	public void searchbox_should_be_displayed() {

		f1.cheakSearchbox();
	}

	@Then("Login button should be displayed")
	public void login_button_should_be_displayed() {
		f1.cheakloginbtn();
	}

	@Then("scrollbar is present")
	public void scrollbar_is_present() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		long documentHeight = (long) js.executeScript("return document.documentElement.scrollHeight;");
		long viewportHeight = (long) js.executeScript("return window.innerHeight;");

		// Check if the document height exceeds the viewport height
		boolean isScrollBarPresent = documentHeight > viewportHeight;

		Assert.assertTrue(isScrollBarPresent, "Scroll bar is not present on the webpage.");

	}

	@When("User hover on New Bikes Dropdown")
	public void user_hover_on_new_bikes_dropdown() {

		f1.hoveract();
	}

	@Then("Dropdown options Should be displayed")
	public void dropdown_options_should_be_displayed() {

		f1.chckNewbikesdrpDown();

	}

	@When("user clicks on the {string}")
	public void user_clicks_on_the(String string) {

		try {
			for (WebElement ele : f1.bikecategory()) {

				if (ele.getText().equalsIgnoreCase(string)) {
					ele.click();
				}

			}

		} catch (StaleElementReferenceException e) {

		}
	}

	@Then("user is nevigated to the upcoming bikes page")
	public void user_is_nevigated_to_the_upcoming_bikes_page() throws IOException {

		Pr = HelperClass.getProperties();
		String expectedTitle = Pr.getProperty("Upcoming_Bikes_PageTitile");
		String actualTitle = driver.getTitle();

		Assert.assertEquals(actualTitle, expectedTitle);

	}

	@When("user  mapulated to the manufacturer dropdown")
	public void user_mapulated_to_the_manufacturer_dropdown() {
		f1.click_Manufactrer();
	}

	@Then("user select {string}")
	public void user_select(String string) {

		Select drpOption = new Select(f1.manufacturerdrpDown);
		drpOption.selectByVisibleText(string);
	}

	@When("User scroll and click View More")
	public void user_scroll_and_click_view_more() {

		f1.scroll_view();

	}

	@Then("List of the bikes is displayed")
	public void list_of_the_bikes_is_displayed() {

		LinkedHashMap<String, List<String>> bikeDetails = f1.getUpcomingBikeDetails();

		System.out.println("All upcoming bike details under 4 Lacks are displayed below :");
		int i = 1;
		for (String key : bikeDetails.keySet()) {
			List<String> detailsList = bikeDetails.get(key);
			System.out.println("\nBike Details" + (i) + ": " + detailsList);
			i++;
		}
	}

	@When("user clicks on Login button")
	public void user_clicks_on_login_button() {

		f1.clickLogin();
		
	}

	@Then("select google as login")
	public void select_google_as_login() {

		f1.selectGoogle();
	}

	@When("user nevigates to login window")
	public void user_nevigates_to_login_window() {

		String originalWindow = driver.getWindowHandle();

		for (String windowHandle : driver.getWindowHandles()) { // to handle windows
			if (!originalWindow.contentEquals(windowHandle)) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@Then("User enter {string} email")
	public void user_enter_email(String string) {

		WebElement mail = f1.enterMail();
		mail.sendKeys(string);
	}

	@Then("click the Next button")
	public void click_the_next_button(){

		f1.clickNext();

	}

	@Then("display the Error message")
	public void display_the_error_message() {
		f1.captureError();
	}

	@When("User hover on  Used Cars")
	public void user_hover_on_used_cars() throws InterruptedException {

		f1.hoverUsedCar();
	}

	@When("User select {string} in Location options")
	public void user_select_in_location_options(String string) {

		try {
			for (WebElement ele : f1.selectLoc()) {

				if (ele.getText().equalsIgnoreCase(string)) {
					ele.click();
				}

			}
		} catch (StaleElementReferenceException e) {

		}

	}

	@When("Scroll till  list of popular Brands")
	public void scroll_till_list_of_popular_brands() {

		f1.scroll_to_popularBrands();
	}

	@Then("User selects brands and displays cars list")
	public void user_selects_brands_and_displays_cars_list() throws InterruptedException {

		f1.extractCarDetails();
	}

}
