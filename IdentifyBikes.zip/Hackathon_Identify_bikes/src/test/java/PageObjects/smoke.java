package PageObjects;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class smoke extends BasePage {

	public smoke(WebDriver driver) {
		super(driver);

	}

	Actions hover = new Actions(driver);
	JavascriptExecutor js = (JavascriptExecutor) driver;

	@FindBy(xpath = "//*[@id='Header']/div/div[1]/div[1]/a/img")
	public WebElement logo;

	@FindBy(xpath = "//input[@id='headerSearch']")
	public WebElement searchbox;

	@FindBy(xpath = "//div[@id='des_lIcon']")
	public WebElement btn;

	@FindBy(xpath = "//a[normalize-space()='New Bikes']")
	public WebElement newBikesHover;

	@FindBy(xpath = "//*[@id='headerNewNavWrap']/nav/div/ul/li[3]/ul")
	public WebElement newBikesdrpDown;

	@FindBy(xpath = "//*[@id='headerNewNavWrap']/nav/div/ul/li[3]/ul/li")
	public static List<WebElement> bikedrpList;

	@FindBy(xpath = "//*[@id='headerNewNavWrap']/nav/div/ul/li[3]/ul/li[5]/span")
	public WebElement drpUpcomingBikes;

	@FindBy(xpath = "//select[@id='makeId']")
	public WebElement manufacturerdrpDown;

	@FindBy(xpath = "//span[@data-track-label='view-more-models-button']")
	public WebElement scrollview;

	@FindBy(xpath = "//span[@class='zw-cmn-loadMore']")
	public WebElement viewMore;

	@FindBy(xpath = "//a[@data-track-label='model-name']")
	public List<WebElement> bikenames;

	// Storing list of web elements for bike price
	@FindBy(xpath = "//a[@data-track-label='model-name']/following-sibling::div[1]")
	public List<WebElement> bikeprices;

	// Storing list of web elements for bike launch date
	@FindBy(xpath = "//a[@data-track-label='model-name']/following-sibling::div[2]")
	public List<WebElement> bikelaunchdate;

	@FindBy(xpath = "//a[@class='c-p'][normalize-space()='Used Cars']")
	public WebElement used_Cars;

	// Storing list of Used cars Locations
	@FindBy(xpath = "//*[@id=\"headerNewNavWrap\"]/nav/div/ul/li[7]/ul/li/div[2]/ul/li")
	public List<WebElement> carsLocation;

	@FindBy(xpath = "//*[@id='forum_login_wrap_lg']")
	public WebElement loginButton;

	@FindBy(xpath = "//*[@id='myModal3-modal-content']/div[1]/div/div[3]/div[6]/div")
	public WebElement selectGoogle;

	@FindBy(xpath = "//input[@id='identifierId']")
	public WebElement enteremail;

	@FindBy(xpath = "//span[normalize-space()='Next']")
	public WebElement nxtButton;

	@FindBy(xpath = "//div[@class='o6cuMc Jj6Lae']")
	public WebElement mailError;

	@FindBy(xpath = "(//a[contains(text(),'Used Cars')])[1]")
	public WebElement usedCar;

	@FindBy(xpath = "//div[@class=\"h-dd-r\"]//ul//li")
	public List<WebElement> location;

	// @FindBy(xpath = "//span[@class='uFm text-center zw-cmn-cursorPointer']")
	@FindBy(xpath = "//div[@class='zm-cmn-colorBlack div-h3']")
	public WebElement scrollCar;

	@FindBy(xpath = "//ul[@class='zw-sr-secLev usedCarMakeModelList popularModels ml-20 mt-10']//li")
	public List<WebElement> brands;

	@FindBy(xpath = "//input[@class='carmmCheck']")
	public List<WebElement> selectBrnds;

	@FindBy(xpath = "//a[@class='fnt-22 zm-cmn-colorBlack n zw-sr-headingPadding clickGtm saveslotno']")
	public List<WebElement> carsName;

	@FindBy(xpath = "//span[@class='zw-cmn-price n pull-left mt-3']")
	public List<WebElement> carsPrice;

	@FindBy(xpath = "//span[@class='zc-7 fnt-14 uLm block']")
	public List<WebElement> carsCity;

	@FindBy(xpath = "//*[@id='thatsAllFolks']")
	public WebElement endCars;

	public void cheakLogo() {

		Assert.assertTrue(logo.isDisplayed());
	}

	public void cheakSearchbox() {

		searchbox.isDisplayed();
	}

	public void cheakloginbtn() {

		btn.isDisplayed();
	}

	public void hoveract() {

		hover.moveToElement(newBikesHover).perform();
	}

	public void chckNewbikesdrpDown() {
		Assert.assertTrue(newBikesdrpDown.isDisplayed());

	}

	public List<WebElement> bikecategory() {
		return bikedrpList;
	}

	public void click_Manufactrer() {
		manufacturerdrpDown.click();
	}

	public void scroll_view() {

		js.executeScript("arguments[0].scrollIntoView();", scrollview);

		js.executeScript("arguments[0].click();", viewMore);
	}

	// Initialising LinkedHashMap to store bike details in ordered way
	LinkedHashMap<String, List<String>> bikeDetailsMap = new LinkedHashMap<>();

	public LinkedHashMap<String, List<String>> getUpcomingBikeDetails() {
		for (int i = 0; i < bikenames.size(); i++) {
			String bikename = bikenames.get(i).getText();
			String bikeprice = bikeprices.get(i).getText();
			String launchdate = bikelaunchdate.get(i).getText();

			// Convert bikeprice to a numeric value for comparison
			String price = bikeprice.replaceAll("[^\\d.]", "").replaceFirst("\\.(?=.*\\.)", "");
			double priceValue = Double.parseDouble(price);

			// Check if the price is less than 4 lakhs
			if (priceValue < 4) {

				// Create a list to store details
				List<String> detailsList = new ArrayList<>();
				detailsList.add(bikename);
				detailsList.add(bikeprice);
				detailsList.add(launchdate);

				// Use 'Bikedetails' as the key and the list of details as the value
				String bikeDetailsKey = "BikeDetails" + (i + 1);
				bikeDetailsMap.put(bikeDetailsKey, detailsList);
			}
		}
		return bikeDetailsMap;
	}

	public void clickLogin() {
		loginButton.click();
	}

	public void selectGoogle() {
		
		selectGoogle.click();
	}

	public WebElement enterMail() {
		return enteremail;
	}

	public void clickNext() {
		nxtButton.click();
	}

	public void captureError() {
		System.out.println(mailError.getText());
	}

	public void hoverUsedCar() throws InterruptedException {
		Thread.sleep(3000);
		Actions hover1 = new Actions(driver);
		hover1.moveToElement(usedCar).build().perform();

	}

	public List<WebElement> selectLoc() {
		return location;
	}

	public void scroll_to_popularBrands() {

		js.executeScript("arguments[0].scrollIntoView;", scrollCar);
	}

	public void extractCarDetails() throws InterruptedException {

		for (int i = 0; i < brands.size(); i++) {

			js.executeScript("arguments[0].click();", selectBrnds.get(i));

			js.executeScript("arguments[0].scrollIntoView;", endCars);
			// js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
			Thread.sleep(5000);

			for (int j = 0; j < carsName.size(); j++) {

				try {
					System.out.println((j + 1) + "." + carsName.get(j).getText());
					System.out.println(carsPrice.get(j).getText());
					System.out.println(carsCity.get(j).getText());
				}

				catch (Exception e) {

				}
				// Thread.sleep(30000);
			}

			js.executeScript("arguments[0].click();", selectBrnds.get(i));

		}

	}

}
