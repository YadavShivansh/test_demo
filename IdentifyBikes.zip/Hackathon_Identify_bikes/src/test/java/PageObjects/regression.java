package PageObjects;


import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class regression extends BasePage {

	
	public regression(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	Actions act = new Actions(driver);
	JavascriptExecutor js = (JavascriptExecutor)driver; 
	
	@FindBy(xpath="//a[normalize-space()='Used Cars']")
	public WebElement usedCar;
	
	@FindBy(xpath="//ul[@class='h-d-dd h-col-1']")
	public WebElement usedCardrpdown;
	
	@FindBy(xpath="//input[@id='headerSearch']")
	public WebElement searchbox;
	
	@FindBy(xpath="//ul[@id='ui-id-1']")
	 public WebElement searchOption;
	
	@FindBy(xpath = "//*[@id='forum_login_wrap_lg']")
	public WebElement loginButton;

	@FindBy(xpath = "//div[@class='lgn-sc c-p txt-l pl-30 pr-30 googleSignIn']")
	public WebElement selectGoogle;

	@FindBy(xpath = "//input[@type='email']")
	public WebElement enteremail;

	@FindBy(xpath = "//span[normalize-space()='Next']")
	public WebElement nxtButton;

	@FindBy(xpath= "//input[@type='password']")
	public WebElement password;
	
	@FindBy(xpath="//span[contains(text(),'Wrong password. Try again or click Forgot password')]")
	public WebElement passError;
	
	@FindBy(xpath="//div[@onclick='fb_login();']")
	public WebElement Fb;
	
	@FindBy(xpath="//input[@id='email']")
	public WebElement FbEmail;
	
	@FindBy(xpath="//input[@type='password']")
	public WebElement FbPass;
	
	@FindBy(xpath="//input[@type='submit']")
	public WebElement logIn;
	
	@FindBy(xpath="//div[@class='fsl fwb fcb']")
	public WebElement FbError;
	
	@FindBy(xpath="//a[normalize-space()='More']")
	public WebElement more;
	
	@FindBy(xpath="//span[normalize-space()='Sell Car to Cardekho Gaadi Store']")
	public WebElement sellCar;
	
	
	@FindBy(xpath="//a[normalize-space()='New Bikes']")
	public WebElement NewBikes;
	
	
	@FindBy(xpath="//li[normalize-space()='Displacement']")
	public WebElement  Filter;
	
	
	@FindBy(xpath="//div[@class='f-strn f-strnNew gscr_carousel gscr_slide gscr_lsGrab']//a")
	public List<WebElement> range ;
	
	@FindBy(xpath="//strong[@class=\"lnk-hvr block of-hid h-height\"]")
	public List<WebElement>bikeName;
	
	@FindBy(xpath="//div[@class=\"clr-try fnt-14 pb-10 h-height of-hid\"]")
	public List<WebElement>  bikesDisplacement;
	
	@FindBy(xpath="//a[normalize-space()='New Cars']")
	public WebElement NewCars;
	
	@FindBy(xpath="//li[@data-track-label='refine-fuel-tab']")
	public WebElement fuelFitler;
	
	@FindBy(xpath="//div[@data-track-label='refine-fueltype-click']//a")
	public List<WebElement>fuelType;
	
	@FindBy(xpath="//div[@class='clr-try fnt-12 pb-10 ht-spec of-hid']")
	public List<WebElement>carsResults;
	
	
	
	public void hoverUsedcar()
	{
		Actions act = new Actions(driver);
		act.moveToElement(usedCar).perform();
		
	}
	
	public void cheakdrpDown()
	{
		usedCardrpdown.isDisplayed();
	}
	public void clicklogin() {
		loginButton.click();
	}

	public void selectgoogle() {
		
		//selectGoogle.click();
	    js.executeScript("arguments[0].click();",selectGoogle);
		
	}
	
	public void clickSearch()
	{
		searchbox.click();
	}
	
	public void searchOptions()
	{
		searchOption.isDisplayed();
	}
	

	public WebElement enterMail() {
		return enteremail;
	}

	
	public void clickNext() {
		nxtButton.click();
	}

	
	public WebElement enterPass()
	{
		return password;
	}
	
	public void printError()
	{
		System.out.println(passError.getText());
	}
	
	public void selectfb()
	{
		Fb.click();
	}
	
	public WebElement enterCred()
	{
		return FbEmail;
	}
	
	public WebElement enterfbPass()
	{
		return FbPass;
	}
	
	public void fbLogIn()
	{
		logIn.click();
	}
	
	public void Fberror()
	{
		System.out.println(FbError.getText());
	}
	
	
	
	public void hoverMore()
	{
		act.moveToElement(more).perform();
	}
	
	public void clickSellCar()
	{
		 //sellCar.click();
		   
		    js.executeScript("arguments[0].click();",sellCar);
	}
	
	public void clickNewBikes()
	{
		NewBikes.click();
	}
	
	
	
	public void selectFilter()
	{
		//Filter.click();
		js.executeScript("arguments[0].click();",Filter);
	}
	
	public List<WebElement>displacementRanges()

	{ 
		return range;
	}
	
	public void displaysResults()
	{
		for(int i =0; i<bikeName.size();i++)
		{
			System.out.println( bikeName.get(i).getText() +" | " + bikesDisplacement.get(i).getText() );
		}
		
		
	}
	
	public void clickNewCars()
	{
		NewCars.click();
	}
	
	public void selectCarFilterType()
	{
		//fuelFitler.click();
		js.executeScript("arguments[0].click();",fuelFitler);
	}
	
	
	public List<WebElement>fuelTypes()
	{
		return fuelType;
	}
	
	public List<WebElement>filteredResult()
	{    
		return carsResults;
	}
}

