package pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class validateWorldClock extends basePage{

	public validateWorldClock(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}


	WebDriver driver;
	
	
//Locators
	//@FindBy(xpath="//*[@id='vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af']")
	//@FindBy(xpath="//span[@class='fontSizeMedium']//child::strong")
	@FindBy(xpath="//strong[normalize-space()='See all']")
	WebElement worldclock;
	
	@FindBy(xpath="//*[contains(text(), 'World Clock')]")
	WebElement wcText;
	
//xpaths of places	
	@FindBy(xpath="//div[normalize-space()='Bangalore, India (IST)']")
	public WebElement bangalore;
	
	@FindBy(xpath="//div[normalize-space()='London, UK (BST)']")
	public WebElement london;
	
	@FindBy(xpath="//div[normalize-space()='New York, NY (EST)']")
	public WebElement newYork;

// xpath for Times
	
	@FindBy(xpath="//*[@id=\\\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\\\"]/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[1]/span[1]")
	public WebElement bangaloreTime;
	
	@FindBy(xpath="//*[@id=\\\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\\\"]/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[1]/span[2]")
	public WebElement londonTime;
	
	@FindBy(xpath="//*[@id=\\\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\\\"]/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[1]/span[3]")
	public WebElement newYorkTime;
	
//xpath for period of the day in time
	
	@FindBy(xpath="//span[@class='g_b_816e1fa6 h_b_816e1fa6']")
	public WebElement bangaloreTimePeriod;
	
	
	@FindBy(xpath="//*[@id=\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\"]/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[1]/span[2]")
	public WebElement londonTimePeriod;

	
	@FindBy(xpath="//*[@id=\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\"]/div/div[2]/div/div/div/div/div/div[3]/div/div/div/div[2]/div[1]/span[2]")
	public WebElement newYorkTimePeriod;
	

//Day and Date xpaht
	@FindBy(xpath="//*[@id=\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\"]/div/div[2]/div/div/div/div/div/div[1]/div/div/div/div[2]/div[2]/div[2]")
	public WebElement bangaloreDayDate;

	
	@FindBy(xpath="//*[@id=\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\"]/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div[2]")
	public WebElement londonDayDate;
	
	@FindBy(xpath="//*[@id=\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\"]/div/div[2]/div/div/div/div/div/div[3]/div/div/div/div[2]/div[2]/div[2]")
	public WebElement newYorkDayDate;
	
	//xpath of Time Difference between Bangalore and London
	@FindBy(xpath="//*[@id=\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\"]/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div[1]")
	public WebElement TimeDiff1;
	
	//xpath of Time difference between Bangalore and NewYork
	@FindBy(xpath="//*[@id=\"vpc_WebPart.WorldClockWebPart.internal.60655e4a-73c8-49d0-9571-c762791557af\"]/div/div[2]/div/div/div/div/div/div[3]/div/div/div/div[2]/div[2]/div[1]")
	public WebElement TimeDiff2;
	
	
	
	
	
	
	
	
	
//Action methods
	
	public void scroll()
	{	
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();",worldclock);
		
	}

	public void getWcText()
	{
		wcText.getText();
	}
	
	
	//Store places
	public String[] places() {
		String[] p= new String[3];
		p[0]= bangalore.getText();
		p[1]=london.getText();
		p[2]=newYork.getText();
		
		return p;
		}
	
	// Store timings
	public String[] times() {
		String[] t = new String[3];
		t[0]= bangaloreTime.getText()+" "+bangaloreTimePeriod.getText();
		t[1]= londonTime.getText()+" "+londonTimePeriod.getText();
		t[2]= newYorkTime.getText()+" "+newYorkTimePeriod.getText();

		return t;
	}
	
	
	//store  day and Dates
		public String[] DayDate()
		{
			String d[] = new String[3];
			d[0]= bangaloreDayDate.getText();
			d[1] = londonDayDate.getText();
			d[2] = newYorkDayDate.getText();
			
			return d;
		}
	
	//store time difference 
		
		public String[] timeDiff() {
			 String[] diff=new String[2];
			 diff[0]=TimeDiff1.getText();
			 diff[1]=TimeDiff2.getText();
			 
			 return diff;
		}
	
		
}
