package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class oneCognizant {
	
	
	
	
	@Given("user scrolls to One Cognizant button")
	public void user_scrolls_to_one_cognizant_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("user clicks on One cognizant and navigates to one cognizant window")
	public void user_clicks_on_one_cognizant_and_navigates_to_one_cognizant_window() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("user clicks on view all apps")
	public void user_clicks_on_view_all_apps() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("all enabled and disabled alphabetical apps are verified")
	public void all_enabled_and_disabled_alphabetical_apps_are_verified() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("all the apps corresponding to a number are displayed")
	public void all_the_apps_corresponding_to_a_number_are_displayed() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

}
