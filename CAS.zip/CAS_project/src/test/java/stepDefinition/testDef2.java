package stepDefinition;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import factory.baseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import pageObjects.validateWorldClock;

public class testDef2 {
	
	public WebDriver driver;
	public validateWorldClock validWC;
	
	
	@Given("homepage of application")
	public void homepage_of_application() {
		validWC= new validateWorldClock(baseClass.getDriver());
	}
	
	@When("user scrolls till end of page")
	public void user_scrolls_till_end_of_page() {
		
		validWC.scroll();
	}
   

	@Then("world clock should be displayed")
	public void world_clock_should_be_displayed() {
		
		validWC.getWcText();
    
	}
	
	
	@When("timezones of Bangalore, London and NewYork are displayed")
	public void timezones_of_bangalore_london_and_new_york_are_displayed() {
		
	
			Assert.assertTrue(validWC.bangalore.isDisplayed());
		    Assert.assertTrue(validWC.london.isDisplayed());
		    Assert.assertTrue(validWC.newYork.isDisplayed());
	
		
	}

	@Then("tiemzones are verified")
	public void tiemzones_are_verified() {
		
		String[] places = validWC.places();
		String[] Time = validWC.times();
		
		HashMap<String,String> zones=new HashMap<String,String>();
		zones.put(places[0],"Asia/Kolkata");
		zones.put(places[1],"Europe/London");
		zones.put(places[2],"America/New_York");
		
		// use ZonedDateTime class to get get and time of respective zone
		
		ZonedDateTime time1 = ZonedDateTime.now(ZoneId.of(zones.get(places[0])));
		ZonedDateTime time2 = ZonedDateTime.now(ZoneId.of(zones.get(places[1])));
        ZonedDateTime time3 = ZonedDateTime.now(ZoneId.of(zones.get(places[2])));
		
        
        DateTimeFormatter TimeFormate = DateTimeFormatter.ofPattern("h:mm a");
        
        String timing1 =TimeFormate.format(time1);
        String timing2 =TimeFormate.format(time2);
        String timing3 =TimeFormate.format(time3);
        
        Assert.assertEquals(Time[0].toLowerCase(), timing1);
		Assert.assertEquals(Time[1].toLowerCase(), timing2);
		Assert.assertEquals(Time[2].toLowerCase(), timing3);
        
		
	   
		
	}

	@When("Day and date of Bangalore, London and NewYork are displayed")
	public void day_date_of_bangalore_london_and_new_york_are_displayed() {
	    
		Assert.assertTrue(validWC.bangaloreDayDate.isDisplayed());
		Assert.assertTrue(validWC.londonDayDate.isDisplayed());
		 Assert.assertTrue(validWC.newYorkDayDate.isDisplayed());
		
	}

	@Then("Day dates are verified")
	public void day_dates_are_verified() {
		String[] places = validWC.places();
		String[] DayDate = validWC.DayDate();
		
		HashMap<String,String> zones=new HashMap<String,String>();
		zones.put(places[0],"Asia/Kolkata");
		zones.put(places[1],"Europe/London");
		zones.put(places[2],"America/New_York");
		
		// use ZonedDateTime class to get get and time of respective zone
		
		ZonedDateTime time1 = ZonedDateTime.now(ZoneId.of(zones.get(places[0])));
		ZonedDateTime time2 = ZonedDateTime.now(ZoneId.of(zones.get(places[1])));
        ZonedDateTime time3 = ZonedDateTime.now(ZoneId.of(zones.get(places[2])));
		
        
        DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern("EEEE, M/d/yyyy");

        String DayDate1 =CUSTOM_FORMATTER.format(time1);
        String DayDate2 =CUSTOM_FORMATTER.format(time2);
        String DayDate3 =CUSTOM_FORMATTER.format(time3);
        
        Assert.assertEquals(DayDate[0], DayDate1);
 		Assert.assertEquals(DayDate[1], DayDate2);
 		Assert.assertEquals(DayDate[2], DayDate3);
 		
        
	}

	@When("time differences for London and NewYork are displayed")
	public void time_differences_for_london_and_new_york_are_displayed() {
	    
		Assert.assertTrue(validWC.TimeDiff1.isDisplayed());
		Assert.assertTrue(validWC.TimeDiff2.isDisplayed());
		
	}

	@Then("time differneces are compared to Bangalore time")
	public void time_differneces_are_compared_to_bangalore_time() {
	    
		
	}

	
	

}
